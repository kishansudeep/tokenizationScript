#!/usr/bin/sh
 
if [ $# -eq 3 ]
then
    inputFile="$1"
    propFile="$2"
    outputFile="$3"

    var="$(cat $inputFile)";
    while IFS="=" read -r key value; do
	var="${var/"[["$key"]]"/$value}";
    done<$propFile;
 
    echo "Writing out file"
    echo "$var">$outputFile
else
    echo "Wrong argument. Please follow : "
    echo "inputFile configProperty outputFile"
fi
